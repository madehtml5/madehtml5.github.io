<?php
$_['heading_title']               = '<i class="fa fa-html5" style="color:#000; text-align:left; font-size:1.25em" aria-hidden="true"></i>&nbsp;&nbsp;<span style="font-weight:800; text-align:left; font-size:1.25em"><span style="color:#003366;">Theme Control Panel</span>';
$_['text_extension']              = 'Extensions';
$_['result_success']                = 'Success: Your changes have been saved';
$_['text_success']                = 'Success: Your changes have been saved';
$_['text_edit']        			  = 'Edit';
$_['text_left']                   = 'Left';
$_['text_right']                  = 'Right';
$_['text_select']                 = 'Select';
$_['text_clear']                  = 'Clear';
$_['entry_position']              = 'Position:';
$_['entry_status']                = 'Status:';
$_['entry_sort_order']            = 'Sort Order:';
$_['error_permission']            = 'Warning: You do not have PERMISSION to modify Moderns Theme Control Panel!';