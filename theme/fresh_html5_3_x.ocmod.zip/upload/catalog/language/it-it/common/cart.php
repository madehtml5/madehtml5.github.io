<?php
// Text
$_['text_items']    = '%s';
$_['text_empty']    = 'Il carrello &egrave; vuoto!';
$_['text_cart']     = 'Guarda il Carrello';
$_['text_checkout'] = 'Checkout';
$_['text_recurring']  = 'Profilo di Pagamento';