<?php
// Text
$_['text_items']      = '%s';
$_['text_empty']      = '您的購物車沒有加入任何商品';
$_['text_cart']     = '觀看內容';
$_['text_checkout'] = '前往結帳';
$_['text_recurring']  = '分期付款';