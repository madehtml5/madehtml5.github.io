<?php
// Text
$_['text_items']     = '%s';
$_['text_empty']     = 'ショッピングカートに商品はありません!';
$_['text_cart']      = 'カートを見る';
$_['text_checkout']  = 'レジへ進む';
$_['text_recurring'] = '支払プロファイル';