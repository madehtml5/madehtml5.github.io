<?php
// Text
$_['text_items']    = '%s';
$_['text_empty']    = 'Tu carro esta vac&iacute;o!';
$_['text_cart']     = 'Ver Carrito';
$_['text_checkout'] = 'Caja';
$_['text_recurring']  = 'Perfil de pago';