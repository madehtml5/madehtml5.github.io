<?php
// Heading
$_['header_filter'] = 'Фільтр';

$_['price_filter'] = 'Ціна';
$_['manufacturer_filter'] = 'Виробники';
$_['button_filter'] = '<i class="bi bi-funnel"></i> фільтрувати';
			