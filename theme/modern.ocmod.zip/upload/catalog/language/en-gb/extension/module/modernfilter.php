<?php
// Heading
$_['header_filter'] = 'Filter';

$_['price_filter'] = 'Price';
$_['manufacturer_filter'] = 'Manufacturer';
$_['button_filter'] = '<i class="bi bi-funnel"></i> filter';
			