<?php
// Heading
$_['header_filter'] = 'Фильтр';

$_['price_filter'] = 'Цена';
$_['manufacturer_filter'] = 'Производители';
$_['button_filter'] = '<i class="bi bi-funnel"></i> фильтровать';
			