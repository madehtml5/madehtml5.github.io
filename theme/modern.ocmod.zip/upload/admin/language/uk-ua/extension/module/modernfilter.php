<?php
// Heading
$_['heading_title']    = '<i class="fa fa-bolt" style="color:#990000; text-align:left; font-size:1.25em" aria-hidden="true"></i>&nbsp;&nbsp;<span style="font-weight:800; text-align:left; font-size:1.25em"><span style="color:#003366;">Modernфільтр</span>';

// Text
$_['text_extension']   = 'Модулі';
$_['text_success']     = 'Успіх: Ви змінили модуль!';
$_['text_edit']        = 'Редагувати модуль';

// Entry
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify modernfilter module!';