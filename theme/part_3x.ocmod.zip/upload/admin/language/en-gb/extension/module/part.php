<?php
// Heading
$_['heading_title']                    = '<i class="fa fa-html5" style="color:#000;" aria-hidden="true"></i>&nbsp;&nbsp;<span style="font-weight:800;color:#003366;">Theme Control Panel by <a href="https://madehtml5.github.io/" target="_blank">https://madehtml5.github.io/</a></span>';
$_['heading_title1']                    = '<i class="fa fa-html5" style="color:#000;" aria-hidden="true"></i>&nbsp;Theme Control Panel';

$_['text_success']                     = 'Success: You have modified store theme!';
$_['text_edit']                        = 'Edit';
// Entry
$_['text_extension']                   = 'Extensions';
$_['entry_status']                     = 'Status';
$_['error_permission']                 = 'Warning: You do not have permission to modify store theme!';