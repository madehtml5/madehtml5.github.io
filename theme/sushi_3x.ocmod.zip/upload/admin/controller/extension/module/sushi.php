<?php
class ControllerExtensionModuleSushi extends Controller
{
    private $error = [];
    public function index()
    {
        $this->load->language("extension/module/sushi");
        $this->load->model("tool/image");
        $this->load->model("setting/setting");
        if ($this->request->server["REQUEST_METHOD"] == "POST" && $this->validate()) {
            $this->model_setting_setting->editSetting("sushi", $this->request->post);
            $this->session->data["success"] = $this->language->get("text_success");
             if(isset($this->request->post['save_stay']) and $this->request->post['save_stay']=1)
			$this->response->redirect($this->url->link('extension/module/sushi', 'user_token=' . $this->session->data['user_token'], true));
			else
			$this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true));
        }
        $this->document->addScript("view/javascript/summernote/summernote.js");
        $this->document->addScript("view/javascript/summernote/summernote-image-attributes.js");
        $this->document->addScript("view/javascript/summernote/opencart.js");
        $this->document->addStyle("view/javascript/summernote/summernote.css");
        $this->document->addStyle("view/stylesheet/codemirror/lib/codemirror.css?");
        $this->document->addStyle("view/stylesheet/codemirror/mode/theme/monokai.css?");
        $this->document->addScript("view/javascript/codemirror/lib/codemirror.js");
        $this->document->addScript("view/javascript/codemirror/mode/css/css.js");
        $this->document->addScript("view/javascript/codemirror/mode/javascript/javascript.js");
        $data["heading_title"] = $this->language->get("heading_title");
        $data["user_token"] = $this->session->data["user_token"];
        if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}
        $data["breadcrumbs"] = [];
        $data["breadcrumbs"][] = [
            "text" => $this->language->get("text_home"),
            "href" => $this->url->link("common/dashboard", "user_token=" . $this->session->data["user_token"], true),
        ];
        $data["breadcrumbs"][] = [
            "text" => $this->language->get("text_extension"),
            "href" => $this->url->link("marketplace/extension", "user_token=" . $this->session->data["user_token"] . "&type=module", true),
        ];
        $data["breadcrumbs"][] = [
            "text" => $this->language->get("heading_title"),
            "href" => $this->url->link("extension/module/sushi", "user_token=" . $this->session->data["user_token"], true),
        ];
       $data['action'] = $this->url->link('extension/module/sushi', 'user_token=' . $this->session->data['user_token'], true);
        $data["cancel"] = $this->url->link("marketplace/extension", "user_token=" . $this->session->data["user_token"] . "&type=module", true);
        $this->load->model("localisation/language");
        $data["languages"] = $this->model_localisation_language->getLanguages();
        $data["lang"] = $this->language->get("lang");
        $config = [
            "sushi_url" => [],
            "sushi_sticky_header" => "1", 
            "sushi_color_main" => "",
			"sushi_color_main2" => "",
			"sushi_color_main3" => "",
            "sushi_text_color" => "",
            "sushi_text_color2" => "",
            "sushi_font" => "",
            "sushi_custom_css" => "",
            "sushi_custom_js" => "",
           
            "sushi_topbanner_show" => "0",
            "sushi_topbanner_img" => "",
            "sushi_topbanner_link" => "",
        ];
        if (isset($this->request->post["sushi_topbanner_img"]) && is_file(DIR_IMAGE . $this->request->post["sushi_topbanner_img"])) {
            $data["sushi_topbanner_img_preview"] = $this->model_tool_image->resize($this->request->post["sushi_topbanner_img"], 100, 100);
        } elseif ($this->config->get("sushi_topbanner_img") && is_file(DIR_IMAGE . $this->config->get("sushi_topbanner_img"))) {
            $data["sushi_topbanner_img_preview"] = $this->model_tool_image->resize($this->config->get("sushi_topbanner_img"), 100, 100);
        } else {
            $data["sushi_topbanner_img_preview"] = $this->model_tool_image->resize("no_image.png", 100, 100);
        }
        foreach ($config as $key => $result) {
            if (isset($this->request->post[$key])) {
                $data[$key] = $this->request->post[$key];
            } elseif (isset($setting_info[$key])) {
                $data[$key] = $setting_info[$key];
            } else {
                $data[$key] = $this->config->get($key);
            }
        }
        $data["header"] = $this->load->controller("common/header");
        $data["column_left"] = $this->load->controller("common/column_left");
        $data["footer"] = $this->load->controller("common/footer");
        $this->response->setOutput($this->load->view("extension/module/sushi", $data));
    }
    protected function validate()
    {
        if (!$this->user->hasPermission("modify", "extension/module/sushi")) {
            $this->error["warning"] = $this->language->get("error_permission");
        }
        if (isset($this->request->post["sushi_url"])) {
            $menu_url = $this->request->post["sushi_url"];
            foreach ($menu_url as $key => $entry) {
                foreach ($entry["name"] as $language_id => $name) {
                    if (empty($name)) {
                        $this->error["sushi_url"][$key]["name"][$language_id] = true;
                    }
                }
                foreach ($entry["url"] as $language_id => $url) {
                    if (empty($url)) {
                        $this->error["sushi_url"][$key]["url"][$language_id] = true;
                    }
                }
            }
        }
       
        return !$this->error;
    }
    public function install()
    {
        $this->load->model("setting/setting");
        $this->load->model("setting/module");
        $config = [
		"sushi_sticky_header" => "1",
		"sushi_color_main3" => "#D4D4D4",
		"sushi_color_main2" => "#5A616E",
        "sushi_color_main" => "#F5C332",
        "sushi_text_color" => "#231E41",
        "sushi_text_color2" => "#fff",
        "sushi_topbanner_show" => "0",
        ];
        $data_module = ["status" => 1];
        $this->model_setting_setting->editSetting("sushi", $config);
    }
    public function uninstall()
    {
        $this->load->model("setting/setting");
        $this->model_setting_setting->deleteSetting("sushi");
    }
}
