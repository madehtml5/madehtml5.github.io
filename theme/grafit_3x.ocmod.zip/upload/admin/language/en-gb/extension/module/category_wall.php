<?php
// Heading
$_['heading_title']    = '<i class="fa fa-html5" style="color:#000; text-align:left; font-size:1.25em" aria-hidden="true"></i>&nbsp;&nbsp;<span style="font-weight:800; text-align:left; font-size:1.25em"><span style="color:#003366;">Category wall</span><a href="https://madehtml5.github.io/" target="_blank" title="https://madehtml5.github.io/" style="color:#ff7361"><i class="fa fa-info-circle"></i></a> ';

// Text
$_['text_module']      = 'Modules';
$_['text_success']     = 'Success: You have modified module!';
$_['text_edit']        = 'Edit Module';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify module!';