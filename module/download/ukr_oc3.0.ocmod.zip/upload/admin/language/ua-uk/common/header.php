<?php
// Heading
$_['heading_title'] = 'Адміністрування';

// Text
$_['text_order'] = 'Замовлення';
$_['text_processing_status'] = 'Статуси замовлень';
$_['text_complete_status'] = 'Завершено';
$_['text_customer'] = 'Клієнти';
$_['text_online'] = 'Клієнти Online';
$_['text_approval'] = 'Очікують схвалення';
$_['text_product'] = 'Товари';
$_['text_stock'] = 'Немає';
$_['text_review'] = 'Відгуки';
$_['text_return'] = 'Повернення';
$_['text_affiliate'] = 'Партнерська програма';
$_['text_store'] = 'Магазин';
$_['text_front'] = 'Магазин';
$_['text_help'] = 'Допомога';
$_['text_homepage'] = 'Сайт ';
$_['text_support'] = 'Форум';
$_['text_documentation'] = 'Документація';
$_['text_logout'] = 'Вихід';