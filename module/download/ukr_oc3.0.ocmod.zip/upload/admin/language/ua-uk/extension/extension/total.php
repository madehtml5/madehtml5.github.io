<?php
// Heading
$_['heading_title'] = 'Враховувати в замовленні';

// Text
$_['text_success'] = 'Налаштування успішно оновлені!';
$_['text_list'] = 'Враховувати в замовленні';

// Column
$_['column_name'] = 'Враховувати в замовленні';
$_['column_status'] = 'Статус';
$_['column_sort_order'] = 'Порядок сортування';
$_['column_action'] = 'Дія';

// Error
$_['error_permission'] = 'У Вас немає прав для управління цим модулем!';