<?php
// Heading
$_['heading_title'] = 'Оплата';

// Text
$_['text_success'] = 'Налаштування успішно оновлені!';
$_['text_list'] = 'Список способів оплати';

// Column
$_['column_name'] = 'Спосіб оплати';
$_['column_status'] = 'Статус';
$_['column_sort_order'] = 'Порядок сортування';
$_['column_action'] = 'Дія';

// Error
$_['error_permission'] = 'У Вас немає прав для управління модулем Оплата!';