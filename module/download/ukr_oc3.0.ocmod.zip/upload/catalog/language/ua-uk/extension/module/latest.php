<?php
// Heading
$_['heading_title'] = 'Нові надходження';

// Text
$_['text_tax'] = 'Без ПДВ:';