<?php
// Text
$_['text_title'] = 'Безкоштовна доставка';
$_['text_description'] = 'Безкоштовна доставка';