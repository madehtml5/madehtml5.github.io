<?php
// Text
$_['text_title'] = 'PayPal Експрес-платежі';
$_['text_canceled'] = 'Оплата успішно скасована!';

// Button
$_['button_cancel'] = 'Відмінити періодичні платежі';

// Error
$_['error_not_cancelled'] = 'Помилка: %s';
$_['error_not_found'] = 'не Можна скасувати профіль';