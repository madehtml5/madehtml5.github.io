<?php
// Heading
$_['heading_title'] = 'Змінити пароль';

// Text
$_['text_account'] = 'Особистий Кабінет';
$_['text_password'] = 'пароль';
$_['text_success'] = 'Ваш пароль успішно змінено!';

// Entry
$_['entry_password'] = 'Пароль';
$_['entry_confirm'] = 'Підтвердіть пароль';

// Error
$_['error_password'] = 'Пароль має бути від 4 до 20 символів!';
$_['error_confirm'] = 'Паролі і пароль підтвердження не збігаються!';