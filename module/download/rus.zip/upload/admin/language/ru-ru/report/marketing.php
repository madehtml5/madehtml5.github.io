<?php
// Heading
$_['heading_title']    = 'Отчет по маркетинговым акциям';

// Text
$_['text_list']        = 'Список акций';
$_['text_all_status']  = 'Все статусы';

// Column
$_['column_campaign']  = 'Название акции';
$_['column_code']      = 'Код';
$_['column_clicks']    = 'Переходов';
$_['column_orders']    = 'Количество заказов';
$_['column_total']     = 'Итого';

// Entry
$_['entry_date_start'] = 'Дата начала';
$_['entry_date_end']   = 'Дата окончания';
$_['entry_status']     = 'Статус заказа';

