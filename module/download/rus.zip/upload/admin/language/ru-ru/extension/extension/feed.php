<?php
// Heading
$_['heading_title']    = 'Каналы продвижения';

// Text
$_['text_success']     = 'Настройки успешно обновлены!';
$_['text_list']        = 'Список каналов';

// Column
$_['column_name']      = 'Название канала';
$_['column_status']    = 'Статус';
$_['column_action']    = 'Действие';

// Error
$_['error_permission'] = 'У Вас нет прав для изменения канала товаров!';

