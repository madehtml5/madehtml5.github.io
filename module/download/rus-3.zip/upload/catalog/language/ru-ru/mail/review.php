<?php
// Text
$_['text_subject']  = '%s - отзыв о товаре';
$_['text_waiting']  = 'Новые отзывы ожидают вашей проверки .';
$_['text_product']  = 'Товар: %s';
$_['text_reviewer'] = 'Отзыв оставил: %s';
$_['text_rating']   = 'Оценка: %s';
$_['text_review']   = 'Отзыв:';

