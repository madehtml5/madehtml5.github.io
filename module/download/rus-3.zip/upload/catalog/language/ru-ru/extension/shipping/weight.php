<?php
// Text
$_['text_title']  = 'Доставка в зависимости от веса';
$_['text_weight'] = 'Вес:';

