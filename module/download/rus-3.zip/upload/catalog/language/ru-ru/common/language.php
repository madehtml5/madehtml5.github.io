<?php
// Text
$_['text_language'] = 'Язык';
