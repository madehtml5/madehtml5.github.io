<?php

$_['heading_title']    = 'Каптча стандартна';

// Text
$_['text_captcha']     = 'Каптча';
$_['text_success']     = 'Налаштування Basic Captcha успішно оновлені!';
$_['text_edit']        = 'Редагування Basic Captcha';

// Entry
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'У Вас немає прав для управління цим модулем !';
