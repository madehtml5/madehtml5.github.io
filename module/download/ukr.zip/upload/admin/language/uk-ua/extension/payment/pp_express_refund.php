<?php

// Heading
$_['heading_title']		   = 'Повернення транзакції';

// Text
$_['text_pp_express']	   = 'PayPal Экспресс-платежі';
$_['text_current_refunds'] = 'Повернення вже виконане для даної операції. Максимальна сума повернення  ';
$_['text_refund']		   = 'Повернення';

// Entry
$_['entry_transaction_id'] = 'ID транзакції';
$_['entry_full_refund']	   = 'Повне повернення';
$_['entry_amount']		   = 'Сумма';
$_['entry_message']		   = 'Повідомлення';

// Button
$_['button_refund']		   = 'Оформити повернення';

// Error
$_['error_partial_amt']	   = 'Ви повинні ввести частину суми';
$_['error_data']		   = 'Немає даних';

