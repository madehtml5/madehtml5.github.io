<?php

// Heading
$_['heading_title'] 	= 'Самовивіз з магазину';
// Jtext
$_['text shipping'] 	= 'Доставка';
$_['text_success'] 	= 'Зміни успішно внесені до Самовивіз з магазину!';
$_['text_edit'] 	= 'Змінити доставку Самовивіз з магазину';
// Entry
$_['entry_geo_zone'] 	= 'Гео-зони';
$_['entry_status'] 	= 'Статус';
$_['entry_sort_order'] 	= 'Порядок сортування';
// Error
$_['error_permission'] 	= 'Увага: у вас немає прав на зміну Самовивозу з магазину!';