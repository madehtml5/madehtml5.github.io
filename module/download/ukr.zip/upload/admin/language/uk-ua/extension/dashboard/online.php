<?php

// Heading
$_['heading_title'] = 'Покупці онлайн';

// Text
$_['text_view']     = 'Детальніше...';