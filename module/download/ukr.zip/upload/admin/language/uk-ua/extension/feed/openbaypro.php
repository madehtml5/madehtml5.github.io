<?php

// Heading
$_['heading_title']	  	= 'OpenBay Pro модуль';

// Text
$_['text_module']          	= 'Модулі';
$_['text_installed']          	= 'Модуль OpenBay Pro успішно встановлено. Для налаштувань перейдіть у меню: 'Додатки> OpenBay Pro'!';
