<?php

// Heading
$_['heading_title'] = 'Продажі за країнами';

$_['text_order']    = 'Замовлення';
$_['text_sale']     = 'Продажі';