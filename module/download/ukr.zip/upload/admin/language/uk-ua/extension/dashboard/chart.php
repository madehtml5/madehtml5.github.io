<?php

// Heading
$_['heading_title'] = 'Статистика продажів';

// Text
$_['text_order']    = 'Заказів';
$_['text_customer'] = 'Покупців';
$_['text_day']      = 'Сьогодні';
$_['text_week']     = 'За неділю';
$_['text_month']    = 'За місяць';
$_['text_year']     = 'За цей рік';