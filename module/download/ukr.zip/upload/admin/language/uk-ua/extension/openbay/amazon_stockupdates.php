<?php

// Heading
$_['heading_title'] 	= 'Оновлення наявності товарів';
$_['text_openbay'] 	= 'OpenBay Pro';
$_['text_amazon'] 	= 'Amazon EU';

// Text
$_['text_empty'] 	= 'Не вибрано!';

// Entry
$_['entry_date_start'] 	= 'Дата початку';
$_['entry_date_end'] 	= 'Дата закінчення';

// Column
$_['column_ref'] 	= 'Посилання';
$_['column_date_requested'] = 'Необхідна дата';
$_['column_date_updated'] = 'Дата поновлення';
$_['column_status'] 	= 'Статус';
$_['column_sku'] 	= 'Артикул Amazon';
$_['column_stock'] 	= 'Наявність';