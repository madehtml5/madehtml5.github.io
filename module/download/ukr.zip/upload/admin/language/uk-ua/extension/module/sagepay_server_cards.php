<?php
// Heading
$_['heading_title']    = 'Sagepay Server Card Management модуль';

$_['text_extension']   = 'Розширення';
$_['text_success']     = 'Успішно: Ви модифікували модуль Sagepay Server Card Management module!';
$_['text_edit']        = 'Редагувати Sagepay Server Card Management Module';

// Entry
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'Увага! У Вас немає дозволів для модифікації Sagepay Server Card Management module!';