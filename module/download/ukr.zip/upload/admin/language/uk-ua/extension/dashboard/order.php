<?php

// Heading
$_['heading_title'] = 'Усього замовлень';

// Text
$_['text_view']     = 'Детальніше...';