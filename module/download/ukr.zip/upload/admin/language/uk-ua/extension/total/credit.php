<?php

// Heading
$_['heading_title']    = 'Кредит магазину';

// Text
$_['text_total']       = 'Загальна сума замовлення';
$_['text_success']     = 'Налаштування модуля оновлені!';
$_['text_edit']        = 'Редагування модуля';

// Entry
$_['entry_status']     = 'Статус:';
$_['entry_sort_order'] = 'Порядок сортування:';

// Error
$_['error_permission'] = 'У Вас немає прав для управління Кредитами магазину!';