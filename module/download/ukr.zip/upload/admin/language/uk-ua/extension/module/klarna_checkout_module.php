<?php

// Heading
$_['heading_title']	   = 'Klarna Checkout модуль';

// Text
$_['text_extension']   = 'Розширення/модулі';
$_['text_success']	   = 'Успішно: Ви модифікували модуль Klarna Checkout!';

//Entry
$_['entry_status']	   = 'Статус';

//Error
$_['error_permission'] = 'Увага: У Вас немає дозволів для модифікації модуля Klarna Checkout!';