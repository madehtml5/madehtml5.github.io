<?php

// Heading
$_['heading_title'] 	= 'Усього покупців';

// Text
$_['text_view'] 	= 'Детальніше...';