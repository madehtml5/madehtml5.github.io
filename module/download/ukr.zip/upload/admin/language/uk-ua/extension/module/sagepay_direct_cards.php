<?php

// Heading
$_['heading_title']    = 'Sagepay Direct Card Management модуль';

$_['text_extension']   = 'Розширення';
$_['text_success']     = 'Успішно: Ви модифікували модуль Sagepay Direct Card Management!';
$_['text_edit']        = 'Редагувати модуль Sagepay Direct Card Management';

// Entry
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'Увага: Ви не маєте дозволів для редагування модуля Sagepay Direct Card Management!';