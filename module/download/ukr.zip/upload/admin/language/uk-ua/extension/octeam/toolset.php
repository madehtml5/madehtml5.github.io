<?php
// Heading
$_['heading_title']           = 'Інструменти OC Team';

// Text
$_['text_install']            = 'Встановити';
$_['text_uninstall']          = 'Видалити';
$_['text_open']               = 'Відкрити';

// Column
$_['column_name']             = 'Назва Інструмента';
$_['column_description']      = 'Опис Інструмента';
$_['column_action']           = 'Дія';

// Error
$_['error_permission']        = 'У Вас немає права для управління Інструментами OC Team!';
?>