<?php

// Heading
$_['heading_title'] 	= 'Оновлення магазина';
$_['text_openbay'] 	= 'OpenBay Pro';
$_['text_amazon'] 	= 'Amazon USA';

// Text
$_['text_empty'] 	= 'Немає результатів!';

// Entry
$_['entry_date_start'] 	= 'Дата початку';
$_['entry_date_end'] 	= 'Дата закінчення';

// Column
$_['column_ref'] 	= 'Посилання';
$_['column_date_requested'] = 'Необхідна дата';
$_['column_date_updated'] = 'Дата поновлення';
$_['column_status']	= 'Статус';
$_['column_sku'] 	= 'Артикул Amazon';
$_['column_stock'] 	= 'Наявність';