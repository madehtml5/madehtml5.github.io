<?php

// Heading
$_['heading_title'] 	= 'Доставка залежно від суми замовлення';

// Text
$_['text_shipping'] 	= 'Доставка';
$_['text_success'] 	= 'Налаштування модуля оновлені!';

// Entry
$_['entry_rate'] 	= 'Розцінки: <br /> <span class = "help"> Наприклад: 500: 10.00,700: 12.00 Сума: Ціна, Сума: Ціна, і т.д. </span>' ;
$_['entry_tax_class'] 	= 'Податковий клас:';
$_['entry_geo_zone'] 	= 'Географічна зона:';
$_['entry_status'] 	= 'Статус:';
$_['entry_sort_order'] 	= 'Порядок сортування:';

// Error
$_['error_permission'] 	= 'У Вас немає прав для управління цим модулем!';
?>