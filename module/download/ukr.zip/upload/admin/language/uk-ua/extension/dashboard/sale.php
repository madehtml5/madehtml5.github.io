<?php

// Heading
$_['heading_title'] = 'Усього продажів';

// Text
$_['text_view']     = 'Детальніше...';