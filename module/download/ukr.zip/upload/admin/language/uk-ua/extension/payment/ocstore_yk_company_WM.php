<?php

$_['heading_title'] = 'Яндекс.Каса (Webmoney)';
?>