<?php

// Heading
$_['heading_title'] 	= 'Збережені переліки';
$_['text_openbay'] 	= 'OpenBay Pro';
$_['text_amazon'] 	= 'Amazon Європа';

// Text
$_['text_description'] 	= 'Це перелік товару, який збережений і готовий до завантаження на Amazon.';
$_['text_uploaded_alert'] = 'Збережений перелік(и) завантажений!';
$_['text_delete_confirm'] = 'Ви впевнені?';
$_['text_complete'] 	  = 'Переліки завантажені';

// Column
$_['column_name'] 	= 'Ім’я';
$_['column_model'] 	= 'Модель';
$_['column_sku'] 	= 'Артикул';
$_['column_amazon_sku'] = 'Артикул Amazon';
$_['column_action'] 	= 'Дія';