<?php

// Heading
$_['heading_title']    		= 'Google мапа сайту';

// Text
$_['text_feed']          	= 'Канали просування';
$_['text_success']          	= 'Налаштування модуля оновлено!';
$_['text_edit']          	= 'Редагування Google Sitemap';

// Entry
$_['entry_status']          	= 'Статус:';
$_['entry_data_feed']          	= 'Адреса:';

// Error
$_['error_permission']          = 'У Вас немає прав для управління цим модулем!';