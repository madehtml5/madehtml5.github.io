<?php

// Heading
$_['heading_title']    = 'Pilibaba Checkout Button модуль';

// Text
$_['text_extension']   = 'Розширення/модулі';
$_['text_success']     = 'Успішно: Ви модифікували Pilibaba Checkout Button module!';
$_['text_edit']        = 'Редагувати модуль Pilibaba Checkout Button';

// Entry
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'Увага! У Вас немає дозволів для редагування модуля Pilibaba Checkout Button!';