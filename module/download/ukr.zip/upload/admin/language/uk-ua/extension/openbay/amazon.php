<?php

// Heading
$_['heading_title']         		= 'Amazon EU';
$_['text_openbay']			= 'OpenBay Pro';
$_['text_dashboard']			= 'Панель управління Amazon EU';

// Text
$_['text_heading_settings'] 		= 'Налаштування';
$_['text_heading_account'] 		= 'Змінити тарифний план';
$_['text_heading_links'] 		= 'Посилання на товар';
$_['text_heading_register'] 		= 'Зареєструватися';
$_['text_heading_bulk_listing'] 	= 'Основний перелік';
$_['text_heading_stock_updates'] 	= 'Оновлення магазина';
$_['text_heading_saved_listings'] 	= 'Збережені переліки';
$_['text_heading_bulk_linking'] 	= 'Основна зв’язок';