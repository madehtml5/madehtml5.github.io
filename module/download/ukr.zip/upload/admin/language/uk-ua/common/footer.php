<?php

// Text
$_['text_footer'] 	= '<a target='_blank' href='http://opencart.com'>Opencart</a> &copy; 2009-' . date('Y') . ' Всі права захищено.';
$_['text_version'] 	= 'Версія Opencart %s';