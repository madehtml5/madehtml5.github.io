<?php

// Heading
$_['heading_title']    = 'Звіт з Купонів';

// Text
$_['text_list']        = 'Перелік Купонів';

// Column
$_['column_name']      = 'Назва Купона';
$_['column_code']      = 'Код';
$_['column_orders']    = 'Замовлень';
$_['column_total']     = 'Всього';
$_['column_action']    = 'Дія';

// Entry
$_['entry_date_start'] = 'Дата початку:';
$_['entry_date_end']   = 'Дата закінчення:';