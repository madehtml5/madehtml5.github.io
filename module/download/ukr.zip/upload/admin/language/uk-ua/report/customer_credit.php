<?php

// Heading
$_['heading_title']         = 'Звіт по Кредитах покупців';

// Column
$_['text_list']             = 'Перелік покупців по Кредитах';
$_['column_customer']       = 'Покупець';
$_['column_email']          = 'E-Mail';
$_['column_customer_group'] = 'Група покупця';
$_['column_status']         = 'Статус';
$_['column_total']          = 'Разом';
$_['column_action']         = 'Дія';

// Entry
$_['entry_date_start']      = 'Дата початку:';
$_['entry_date_end']        = 'Дата закінчення:';