<?php

// Heading
$_['heading_title'] 	= 'Звіт по Комісіях партнерів';
// Jtext
$_['text_list'] 	= 'Перелік партнерів по Комісіям';
// Column
$_['column_affiliate'] 	= 'Ім’я партнера';
$_['column_email'] 	= 'E-Mail';
$_['column_status'] 	= 'Статус';
$_['column_commission'] = 'Комісія';
$_['column_orders'] 	= 'Кількість замовлень';
$_['column_total'] 	= 'Разом';
$_['column_action'] 	= 'Дія';
// Entry
$_['entry_date_start'] 	= 'Дата початку:';
$_['entry_date_end'] 	= 'Дата закінчення:';