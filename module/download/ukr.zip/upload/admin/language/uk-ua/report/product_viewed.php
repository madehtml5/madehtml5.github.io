<?php

// Heading
$_['heading_title']    = 'Звіт з Переглянутих товарів';

// Text
$_['text_list']        = 'Перелік Переглянутих товарів';
$_['text_success']     = 'Звіт по товарах успішно скинутий!';

// Column
$_['column_name']      = 'Найменвання товара';
$_['column_model']     = 'Модель';
$_['column_viewed']    = 'Переглядів';
$_['column_percent']   = 'В процентах';

// Error
$_['error_permission'] = 'У Вас немає прав переглядати цей звіт!';