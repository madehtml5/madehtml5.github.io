<?php

// Heading
$_['heading_title'] 	= 'Активність Партнерів на сайті';
// Jtext
$_['text_list'] 	= 'Перелік активності Партнерів';
$_['text_edit'] 	= '<a href="affiliate_id=%d">%s </a> оновив свої реквізити.';
$_['text_forgotten'] 	= '<a href="affiliate_id=%d">%s </a> запросили новий пароль.';
$_['text_login'] 	= '<a href="affiliate_id=%d">%s </a> авторизувався.';
$_['text_password'] 	= '<a href="affiliate_id=%d">%s </a> оновив пароль від облікового запису.';
$_['text_payment'] 	= '<a href="affiliate_id=%d">%s </a> оновили реквізити для виплат.';
$_['text_register'] 	= '<a href="affiliate_id=%d">%s </a> зареєструвався.';
// Column
$_['column_affiliate'] 	= 'Партнер';
$_['column_comment'] 	= 'Коментар';
$_['column_ip'] 	= 'IP адреса';
$_['column_date_added'] = 'Дата додавання';
// Entry
$_['entry_affiliate'] 	= 'Партнер:';
$_['entry_ip'] 		= 'IP адреса';
$_['entry_date_start'] 	= 'Дата початку:';
$_['entry_date_end'] 	= 'Дата закінчення:';