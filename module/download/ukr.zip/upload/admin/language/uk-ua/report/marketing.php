<?php

// Heading
$_['heading_title']    = 'Звіт з Маркетингу';

// Text
$_['text_list']         = 'Перелік з Маркетингу';
$_['text_all_status']   = 'Всі статуси';

// Column
$_['column_campaign']  = 'Назва компаніі';
$_['column_code']      = 'Код';
$_['column_clicks']    = 'Кліків';
$_['column_orders']    = 'Кількість замовлень';
$_['column_total']     = 'Разом';

// Entry
$_['entry_date_start'] = 'Дата початку:';
$_['entry_date_end']   = 'Дата закінчення:';
$_['entry_status']     = 'Статуси замовлень:';