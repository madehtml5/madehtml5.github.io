<?php

// Heading
$_['heading_title']    = 'Редактор мов';

// Text
$_['text_success']     = 'Налаштування успішно змінені!';
$_['text_edit']        = 'Редагування';
$_['text_default']     = 'По замовчуванні';
$_['text_store']       = 'Магазин';
$_['text_language']    = 'Мова';
$_['text_translation'] = 'Вибрати перекла';
$_['text_translation'] = 'Вибрати переклад';

// Entry
$_['entry_key']        = 'Ключ';
$_['entry_value']      = 'Значення';
$_['entry_default']    = 'По замовчуванню';

// Error
$_['error_permission'] = 'У Вас немає прав для зміни налаштуваннь!';

