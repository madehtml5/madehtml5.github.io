<?php

// Text
$_['text_success'] = 'API сесія успішно запущена!';

// Error
$_['error_key']  = 'УВАГА: API ключ не дійсний !!';
$_['error_ip']   = 'УВАГА: Ваша IP адреса %s не має доступу до API!';
