<?php

// Text
$_['text_subject']  = '%s - Новий пароль';
$_['text_greeting'] = 'Новий пароль був запитаний з %s.';
$_['text_password'] = 'Ваш новий пароль:';
