<?php

// Text
$_['text_new_subject']          = '%s - Замовлення %s';
$_['text_new_greeting']         = 'Дякуємо вам за інтерес до товарів %s. Ваше замовлення буде оброблено після підтвердження оплати.';
$_['text_new_received']         = 'Ви отримали замовлення.';
$_['text_new_link']             = 'Для перегляду замовлення натисніть на посилання нижче:';
$_['text_new_order_detail']     = 'Інформація про замовлення';
$_['text_new_instruction']      = 'Інструкції';
$_['text_new_order_id']         = 'Замовлення №:';
$_['text_new_date_added']       = 'Дата додавання:';
$_['text_new_order_status']     = 'Статус замовлення:';
$_['text_new_payment_method']   = 'Метод оплати:';
$_['text_new_shipping_method']  = 'Метод Доставки:';
$_['text_new_email']  		= 'E-mail:';
$_['text_new_telephone']  	= 'Телефон:';
$_['text_new_ip']  		= 'IP адреса:';
$_['text_new_payment_address']  = 'Адреса платежу';
$_['text_new_shipping_address'] = 'Адреса доставки';
$_['text_new_products']         = 'Товари';
$_['text_new_product']          = 'Товар';
$_['text_new_model']            = 'Модель';
$_['text_new_quantity']         = 'Кількість';
$_['text_new_price']            = 'Ціна';
$_['text_new_order_total']      = 'Підсумок замовлення';
$_['text_new_total']            = 'Разом';
$_['text_new_download']         = 'Після підтвердження платежу Ви можете натиснути на посилання нижче, щоб отримати доступ до завантажуваних товарах:';
$_['text_new_comment']          = 'Коментарі до вашого замовлення:';
$_['text_new_footer']           = 'Будь ласка, відповідайте на цей лист, якщо у Вас є які-небудь питання.';
$_['text_update_subject']       = '%s - ваше замовлення було оновлено до наступного статусу: %s';
$_['text_update_order']         = 'Замовлення №:';
$_['text_update_date_added']    = 'Дата додавання:';
$_['text_update_order_status']  = 'Ваше замовлення було оновлено до наступного статусу:';
$_['text_update_comment']       = 'Коментарі до вашого замовлення:';
$_['text_update_link']          = 'Для перегляду замовлення натисніть на посилання нижче:';
$_['text_update_footer']        = 'Будь ласка, відповідайте на цей лист, якщо у Вас є які-небудь питання.';
