<?php

// Text
$_['text_subject']	= '%s - Відгук на Товар';
$_['text_waiting']	= 'В очікуванні новий відгук на товар.';
$_['text_product']	= 'Товар: %s';
$_['text_reviewer']	= 'Автор: %s';
$_['text_rating']	= 'Рейтинг: %s';
$_['text_review']	= 'Відгук:';