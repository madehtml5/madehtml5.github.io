<?php

// Text
$_['text_title'] = 'Кредитна / Розрахункова картка (LiqPay)';