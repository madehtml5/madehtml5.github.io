<?php

// Calculator
$_['text_checkout_title']      = 'Оплата в розстрочку';
$_['text_choose_plan']         = 'Выберіть свій план';
$_['text_choose_deposit']      = 'Виберіте свій депозит';
$_['text_monthly_payments']    = 'щомісячні виплати';
$_['text_months']              = 'місяці';
$_['text_term']                = 'Термін';
$_['text_deposit']             = 'Депозит';
$_['text_credit_amount']       = 'Вартість кредиту';
$_['text_amount_payable']      = 'Разом до оплати';
$_['text_total_interest']      = 'Загальний розмір процентів';
$_['text_monthly_installment'] = 'Щомісячний платіж';
$_['text_redirection']         = 'Ви будете перенаправлені на Менеджера, для того, щоб завершити цю фінансову заявку, коли ви підтвердите своє замовлення';
