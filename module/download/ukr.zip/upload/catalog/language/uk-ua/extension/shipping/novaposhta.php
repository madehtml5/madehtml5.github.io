<?php

// Text
$_['text_title']    				= 'Нова Пошта';
$_['text_description_Warehouse'] 	= 'Доставка у відділення Нової Пошти';
$_['text_description_Doors'] 		= 'Доставка кур`єром Нової Пошти на адресу';
$_['text_period']					= 'Термін доставки - ';
$_['text_day_1']					= 'день';
$_['text_day_2']					= 'дні';
$_['text_day_3']					= 'днів';