<?php

// Heading
$_['heading_title'] = 'Останні';

// Text
$_['text_tax']      = 'Без податку:';