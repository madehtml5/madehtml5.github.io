<?php

// Heading 
$_['heading_title'] 	 = 'Звісточки';

$_['newletter_lable'] 	 = '<span class="first-text">Підпишіться на</span> <span class="secon-text">цікаві</span>';
$_['newletter_des'] 	 = 'Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat';

//Fields
$_['entry_email'] 		 = 'Email';
$_['entry_name'] 		 = 'Ім"я';

//Buttons
$_['entry_button'] 		 = 'Підписатись<i class="fa fa-long-arrow-right"></i>';
$_['entry_unbutton'] 	 = 'Відписатись';

//text
$_['text_subscribe'] 	 = 'Підписатись зараз';

$_['mail_subject']   	 = 'Підписка на новинки';

//Messages
$_['error_invalid'] 	 = 'Помилка : Будь ласка введіть дійсний Email адрес.';
$_['subscribe']	    	 = 'Успішно : Ви підписались до розсилки новинок.';
$_['unsubscribe'] 	     = 'Успішно : Ви успішно відписались від всіх розсилок.';
$_['alreadyexist'] 	     = 'Помилка : Email вже підписаний на розсилку';
$_['notexist'] 	    	 = 'Помилка : Email не підписаний на розсилку.';
$_['entry_show_again']   =  'Не показувати це повідомлення знову!';