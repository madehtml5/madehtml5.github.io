<?php

// Text
$_['text_title'] = 'Кредитна / Дебетна карта / Paypal / Wallet (G2APay)';