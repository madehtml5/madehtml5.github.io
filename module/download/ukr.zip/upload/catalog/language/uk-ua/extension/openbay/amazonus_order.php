<?php
// Text
$_['text_paid_amazon'] 			= 'Оплата на Amazon US';
$_['text_total_shipping'] 		= 'Доставка';
$_['text_total_shipping_tax'] 	= 'Податок з доставки';
$_['text_total_giftwrap'] 		= 'Подарункова упаковка';
$_['text_total_giftwrap_tax'] 	= 'Податок з суми упаковки';
$_['text_total_sub'] 			= 'Сума';
$_['text_tax'] 					= 'Податок';
$_['text_total'] 				= 'Всього';