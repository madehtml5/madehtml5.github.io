<?php

// Heading
$_['heading_title'] = 'Слайдер роздачі продуктів';

// Text
$_['text_tax']      = 'Без податку';
$_['text_bestseller']   = 'Найпопуляніші';
$_['text_mostviewed']      = 'Найцікавіші';
$_['text_random']      = 'Мені пощастить';
$_['text_special']      = 'Спеціальні';
$_['text_latest']      = 'Останні';
$_['text_sale']      = 'Акція';
$_['text_new']      = 'Новинка';
$_['text_empty_mostviewed']    = 'Немає найчастіше переглядуваних товарів!';
$_['text_empty_random']    = 'Немає випадкових товарів!';
$_['text_empty_special']    = 'Немає спеціальних товарів!';
$_['text_empty_latest']    = 'Немає нових поступленнь!';
$_['text_empty_bestseller']    = 'Немає найпопуляніших товарів!';