<?php

// Text
$_['text_title'] = 'Кредитні / Дебетові картки (2Checkout)';