<?php

// Text
$_['text_title']       = 'Єдина ставка';
$_['text_description'] = 'Фіксована вартість доставки';