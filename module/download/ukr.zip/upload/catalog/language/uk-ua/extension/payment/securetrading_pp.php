<?php


$_['text_title'] 	= 'Кредитна / Дебетовая картка ';
$_['button_confirm'] 	= 'Підтвердити';

$_['text_postcode_check'] = 'Перевірка поштового індекса: %s';
$_['text_security_code_check'] = 'Перевірка CVV2: %s';
$_['text_address_check'] = 'Перевірка адреси: %s';
$_['text_not_given'] 	= 'Немає даних';
$_['text_not_checked'] 	= 'Не перевірено';
$_['text_match'] 	= 'Збігається';
$_['text_not_match'] 	= 'Не збігається';
$_['text_payment_details'] = 'Дані платежу';

$_['entry_card_type'] 	= 'Тип картки';