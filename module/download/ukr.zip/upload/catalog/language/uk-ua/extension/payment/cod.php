<?php

// Text
$_['text_title'] = 'Оплата при отриманні';