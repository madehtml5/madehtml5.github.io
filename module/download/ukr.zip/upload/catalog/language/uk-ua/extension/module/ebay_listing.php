<?php

$_['heading_title'] = 'У магазині eBay';