<?php

// Heading 
$_['heading_title'] = 'Мега Меню вертикальне';

// Text
$_['text_more_vertical_menu'] = 'Більше категорій';
$_['text_close_vertical_menu'] = 'Закрити меню';