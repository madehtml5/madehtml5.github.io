<?php

// Heading
$_['heading_title'] = 'Інформація';

// Text
$_['text_contact']  = 'Зв’язатися з нами';
$_['text_sitemap']  = 'Мапа сайту';