<?php

// Text
$_['text_title']        = 'Pilibaba (Китай)';
$_['text_redirecting']  = 'Перенаправлення...';