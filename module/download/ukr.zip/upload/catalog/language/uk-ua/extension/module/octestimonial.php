<?php

// Heading 
$_['heading_title']  = 'Останні відугки';
$_['text_readmore']  = 'Дізнатись більше';
$_['text_empty']  = 'Немає відгуків';
?>