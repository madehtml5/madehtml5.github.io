<?php

// Heading
$_['heading_title'] = 'Хіти продажів';

// Text
$_['text_tax']      = 'Без податку:';