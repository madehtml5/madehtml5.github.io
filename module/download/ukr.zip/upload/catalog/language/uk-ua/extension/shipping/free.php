<?php

// Text
$_['text_title']       = 'Безкоштовна Доставка';
$_['text_description'] = 'Безкоштовна Доставка';