<?php

// Heading
$_['heading_title']    = 'Особистий Кабінет';

// Text
$_['text_register']    = 'Реєстрація';
$_['text_login']       = 'Авторизація';
$_['text_logout']      = 'Увійти';
$_['text_forgotten']   = 'Нагадати пароль';
$_['text_account']     = 'Особистий кабінет';
$_['text_edit']        = 'Обліковий запис';
$_['text_password']    = 'Зміна пароля';
$_['text_address']     = 'Адреси доставки';
$_['text_wishlist']    = 'Мої закладки';
$_['text_order']       = 'Історія замовлень';
$_['text_download']    = 'Файли для скачування';
$_['text_reward']      = 'Бонусні бали';
$_['text_return']      = 'Повернення товару';
$_['text_transaction'] = 'Історія платежів';
$_['text_newsletter']  = 'Підписка на новини';
$_['text_recurring']   = 'Регулярні платежі';