<?php

	// Text
	$_['text_quickview']  = 'Переглянути'; 
	?>