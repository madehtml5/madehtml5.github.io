<?php

// Heading
$_['heading_title']				   = 'Klarna Checkout';
$_['heading_title_success']		   = 'Ваша Klarna Checkout оплата була виставлена!';

// Text
$_['text_title']				   = 'Klarna Checkout';
$_['text_basket']				   = 'Корзина покупок';
$_['text_checkout']				   = 'Розрахуватись';
$_['text_success']				   = 'Успішно';
$_['text_choose_shipping_method']  = 'Виберіть метод доставки';
$_['text_sales_tax']			   = 'Податкові знижки';