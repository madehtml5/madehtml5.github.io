<?php

// Text
$_['text_title']  = 'Оплата доставки за вагою';
$_['text_weight'] = 'Вага:';