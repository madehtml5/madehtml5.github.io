<?php

// Text
$_['text_title']       = 'Самовивіз';
$_['text_description'] = 'Самовивіз';