<?php

// Text
$_['text_title']    = 'Пошта Австралії';
$_['text_express']  = 'Експрес';
$_['text_standard'] = 'Стандарт';
$_['text_eta']      = 'доби';