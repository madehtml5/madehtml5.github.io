<?php

// Heading
$_['heading_title']    = 'Кабінет Партнера';

// Text
$_['text_register']    = 'Авторизація';
$_['text_login']       = 'Реєстрація';
$_['text_logout']      = 'Вихід';
$_['text_forgotten']   = 'Нагадати пароль';
$_['text_account']     = 'Особистий кабінет';
$_['text_edit']        = 'Дані облікового запису';
$_['text_password']    = 'Зміна пароля';
$_['text_payment']     = 'Спосіб оплати';
$_['text_tracking']    = 'Спрямування Партнера';
$_['text_transaction'] = 'Історія виплат';
