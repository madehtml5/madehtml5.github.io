<?php

// Text
$_['text_title']       = 'PiliExpress доставка';
$_['text_description'] = 'PiliExpress Піліекспрес(Китай), тільки для Pilibaba)';