<?php

// Text
$_['text_title']                               = 'Fedex';
$_['text_weight']                              = 'Вага:';
$_['text_eta']                                 = 'Розрахунковий час:';
$_['text_europe_first_international_priority'] = 'Європа Перший міжнародний пріоритет';
$_['text_fedex_1_day_freight']                 = 'Fedex 1 День перевозка вантажів';
$_['text_fedex_2_day']                         = 'Fedex 2 Дні';
$_['text_fedex_2_day_am']                      = 'Fedex 2 Дні до обіду';
$_['text_fedex_2_day_freight']                 = 'Fedex 2 Дні перевозка вантажів';
$_['text_fedex_3_day_freight']                 = 'Fedex 3 Дні перевозка вантажів';
$_['text_fedex_express_saver']                 = 'Fedex Express Saver';
$_['text_fedex_first_freight']                 = 'Fedex Перший вантажний';
$_['text_fedex_freight_economy']               = 'Fedex Вантажний економний';
$_['text_fedex_freight_priority']              = 'Fedex Пріоритетна перевозка';
$_['text_fedex_ground']                        = 'Fedex Основний';
$_['text_first_overnight']                     = 'First Через ніч';
$_['text_ground_home_delivery']                = 'Ground Доставка додому';
$_['text_international_economy']               = 'Міжнародний Економний';
$_['text_international_economy_freight']       = 'Міжнародний Економний вантажі';
$_['text_international_first']                 = 'Міжнародний Перший';
$_['text_international_priority']              = 'Міжнародний Пріоритетний';
$_['text_international_priority_freight']      = 'Міжнародний Пріоритетний вантажі';
$_['text_priority_overnight']                  = 'Пріоритентний Через ніч';
$_['text_smart_post']                          = 'Smart Post';
$_['text_standard_overnight']                  = 'Стандартний Через ніч';