<?php

// Heading
$_['heading_title'] = 'Нові поступлення';

// Text
$_['text_tax']      = 'Ex Tax:';
$_['text_reviews']             = '%s reviews';
$_['text_sale']      = 'Знижка';
$_['text_new']      = 'Новинка';
$_['text_empty']    = 'Немає нових поступленнь';