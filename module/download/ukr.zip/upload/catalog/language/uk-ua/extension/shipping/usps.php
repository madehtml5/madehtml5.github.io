<?php

// Text
$_['text_title']  = 'United States Postal Service';
$_['text_weight'] = 'Вага:';
$_['text_eta']    = 'Приблизний час:';