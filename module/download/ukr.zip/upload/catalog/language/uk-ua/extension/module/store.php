<?php

// Heading
$_['heading_title'] = 'Оберіть магазин';

// Text
$_['text_default']  = 'За замовчуванням';
$_['text_store']    = 'Оберіть магазин, який бажаєте відвідати.';