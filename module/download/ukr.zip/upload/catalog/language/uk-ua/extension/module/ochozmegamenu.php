<?php

// Heading 
$_['heading_title'] = 'Мега Меню Горизонтальне';

// Text
$_['text_reviews']  = 'Базується на відсотку перекриття';
$_['text_category']  = 'Категорії';