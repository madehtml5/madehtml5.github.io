<?php

// Text
$_['text_title']			= 'Кредитна / Розрахункова картка (Веб Платіж)';
$_['text_credit_card']			= 'Деталі картки';

// Entry
$_['entry_cc_owner']			= 'Власник картки';
$_['entry_cc_number']			= 'Номер картки';
$_['entry_cc_expire_date']		= 'Термін дії картки';
$_['entry_cc_cvv2']			= 'Код безпеки картки (CVV2)';