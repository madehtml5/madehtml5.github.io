<?php

// Heading
$_['heading_title'] = 'Уточнити Пошук';