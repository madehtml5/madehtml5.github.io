<?php

$_['text_readmore'] = 'Дізнатись більше';