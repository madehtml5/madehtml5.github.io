<?php

// Heading
$_['heading_title']    = 'Мапа сайту';

// Text
$_['text_special']     = 'Товари зі знижкою';
$_['text_account']     = 'Особистий кабінет';
$_['text_edit']        = 'Обліковий запис';
$_['text_password']    = 'Зміна пароля';
$_['text_address']     = 'Перелік адрес доставки';
$_['text_history']     = 'Історія замовлень';
$_['text_download']    = 'Файли для скачування';
$_['text_cart']        = 'Кошик покупок';
$_['text_checkout']    = 'Оформлення замовлення';
$_['text_search']      = 'Пошук';
$_['text_information'] = 'Інформація';
$_['text_contact']     = 'Зв’язатися з нами';