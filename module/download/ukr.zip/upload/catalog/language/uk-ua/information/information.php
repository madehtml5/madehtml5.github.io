<?php

// Text
$_['text_error'] = 'Сторінка не знайдена!';