<?php

// Heading
$_['heading_title']   	= 'Файли для скачування';

// Text
$_['text_account']    	= 'Особистий кабінет';
$_['text_downloads']  	= 'Файли для скачування';
$_['text_empty']      	= 'У Вас не було замовлень з файлами для скачування!';

// Column
$_['column_order_id']   = '№ замовлення:';
$_['column_name']       = 'Ім’я:';
$_['column_size']       = 'Розмір:';
$_['column_date_added'] = 'Дата додавання:';