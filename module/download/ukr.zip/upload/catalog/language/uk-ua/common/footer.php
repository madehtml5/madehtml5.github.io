<?php

// Text
$_['text_information']  = 'Інформація';
$_['text_service']      = 'Служба підтримки';
$_['text_extra']        = 'Додатково';
$_['text_contact']      = 'Зв’язатися з нами';
$_['text_return']       = 'Повернення товару';
$_['text_sitemap']      = 'Мапа сайту';
$_['text_manufacturer'] = 'Виробники';
$_['text_voucher']      = 'Подарункові сертифікати';
$_['text_affiliate']    = 'Партнери';
$_['text_special']      = 'Товари зі знижкою';
$_['text_account']      = 'Особистий кабінет';
$_['text_order']        = 'Історія замовлень';
$_['text_wishlist']     = 'Мої закладки';
$_['text_newsletter']   = 'Розсилка новин';
$_['text_powered']    = '%s &copy; %s';  
$_['text_search']      = 'Пошук товарів в каталозі';