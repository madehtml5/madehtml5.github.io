<?php

// Text
$_['text_home']          = 'Головна';
$_['text_wishlist']      = 'Мої Закладки (%s)';
$_['text_shopping_cart'] = 'Кошик замовлень';
$_['text_category']      = 'Категорії';
$_['text_account']       = 'Особистий кабінет';
$_['text_register']      = 'Реєстрація';
$_['text_login']         = 'Авторизація';
$_['text_order']         = 'Історія замовлень';
$_['text_transaction']   = 'Історія платежів';
$_['text_download']      = 'Файли для скачування';
$_['text_logout']        = 'Вихід';
$_['text_checkout']      = 'Оформлення замовлення';
$_['text_search']        = 'Пошук';
$_['text_all']           = 'Показати всі';
$_['text_page']          = 'Сторінка';
$_['text_telephone']           = 'Зв’яжіться з нами     :';
$_['text_top_head']           = 'Сезон знижок! 70%. Використайте код: “SALE70”. Поспішайте!  > ';