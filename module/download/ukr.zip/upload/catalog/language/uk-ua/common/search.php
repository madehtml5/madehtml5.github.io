<?php

// Text
$_['text_search'] = 'Пошук товару у каталозі';