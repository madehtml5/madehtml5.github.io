<?php
// Заголовок
$_['text_checkout_create_account_login'] = 'Учетная запись';
$_['text_confirm_order'] = 'Подтвердить заказ';
$_['text_shipping_address'] = 'Адрес доставки';
$_['text_title_shipping_method'] = 'Способ доставки';
$_['text_title_payment_method'] = 'Способ оплаты';
$_['text_coupon_voucher'] = 'У вас есть купон или ваучер?';
$_['text_enter_coupon_code'] = 'Код купона';
$_['text_enter_voucher_code'] = 'Код ваучера';
$_['text_apply_voucher'] = 'Ваучер';
$_['text_apply_coupon'] = 'Купон';
$_['text_enter_reward_points'] = 'Введите бонусные баллы';
$_['text_apply_points'] = 'Применить баллы';
$_['text_shopping_cart'] = 'Корзина';
$_['text_payment_detail'] = 'Детали платежа';
$_['entry_fax'] = 'Факс';

//Ошибка
$_['error_comment'] = 'Вы должны добавить комментарии к вашему заказу';