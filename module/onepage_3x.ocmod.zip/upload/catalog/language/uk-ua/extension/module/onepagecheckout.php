<?php
// Заголовок
$_['text_checkout_create_account_login'] = 'Обліковий запис';
$_['text_confirm_order'] = 'Підтвердити замовлення';
$_['text_shipping_address'] = 'Адреса доставки';
$_['text_title_shipping_method'] = 'Спосіб доставки';
$_['text_title_payment_method'] = 'Метод оплати';
$_['text_coupon_voucher'] = 'У вас є купон або ваучер?';
$_['text_enter_coupon_code'] = 'Код купона';
$_['text_enter_voucher_code'] = 'Код ваучера';
$_['text_apply_voucher'] = 'Ваучер';
$_['text_apply_coupon'] = 'Купон';
$_['text_enter_reward_points'] = 'Введіть бонусні бали';
$_['text_apply_points'] = 'Застосувати бали';
$_['text_shopping_cart'] = 'Кошик для покупок';
$_['text_payment_detail'] = 'Деталі платежу';
$_['entry_fax'] = 'Факс';

//Помилка
$_['error_comment'] = 'Ви повинні додати коментарі до свого замовлення';