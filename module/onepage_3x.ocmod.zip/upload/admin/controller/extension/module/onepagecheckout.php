<?php
class ControllerExtensionModuleOnepageCheckout extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('extension/module/onepagecheckout');
		$this->document->setTitle($this->language->get('heading_title'));
		$data['lang']	= $this->language;

		$this->load->model('setting/module');
		$this->load->model('setting/setting');
		$this->load->model('extension/module/onepagecheckout');
		$this->load->model('localisation/country');

		$module_id = '';
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			$action = isset($this->request->post["action"]) ? $this->request->post["action"] : "";
			unset($this->request->post['action']);
			
			$params 				= $this->request->post['onepagecheckout'];
			$params_general 		= $this->request->post['onepagecheckout']['onepagecheckout_general'];
			$params_layout_setting 	= $this->request->post['onepagecheckout']['onepagecheckout_layout_setting'];
			$this->model_setting_setting->editSetting('onepagecheckout', $params);
			
			$params_module = array('name'=>$params_general['onepagecheckout_name'], 'status'=>$params_general['onepagecheckout_enabled']);
			
			if (!isset($this->request->get['module_id'])) {
				$this->model_setting_module->addModule('onepagecheckout', $params_module);
				$module_id = $this->db->getLastId();
			}
			else {
				$module_id = $this->request->get['module_id'];
				$this->model_setting_module->editModule($this->request->get['module_id'], $params_module);
			}

			$this->session->data['success'] = $this->language->get('text_success');

			if($action == "save_edit") {
				$this->response->redirect($this->url->link('extension/module/onepagecheckout', 'user_token=' . $this->session->data['user_token'] . '&module_id='.$module_id, 'SSL'));
			}elseif($action == "save_new"){
				$this->response->redirect($this->url->link('extension/module/onepagecheckout', 'user_token=' . $this->session->data['user_token'], 'SSL'));
			}else{
				$this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true));
			}
		}
		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];
			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], 'SSL')
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_module'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'], 'SSL')
		);

		if (!isset($this->request->get['module_id'])) {
			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('heading_title'),
				'href' => $this->url->link('extension/module/onepagecheckout', 'user_token=' . $this->session->data['user_token'], 'SSL')
			);
		} else {
			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('heading_title'),
				'href' => $this->url->link('extension/module/onepagecheckout', 'user_token=' . $this->session->data['user_token'] . '&module_id=' . $this->request->get['module_id'], 'SSL')
			);			
		}
		$data['countries']	= $this->model_localisation_country->getCountries();
		$data['user_token']	= $this->session->data['user_token'];

		$data['text_yes'] 						= $this->language->get('text_yes');
		$data['text_no'] 						= $this->language->get('text_no');
		$data['text_default_country'] 			= $this->language->get('text_default_country');
		$data['text_default_zone'] 				= $this->language->get('text_default_zone');
		$data['text_register_account'] 			= $this->language->get('text_register_account');
		$data['text_guest_checkout'] 			= $this->language->get('text_guest_checkout');
		$data['text_login_checkout'] 			= $this->language->get('text_login_checkout');
		$data['text_default_display'] 			= $this->language->get('text_default_display');
		$data['text_register'] 					= $this->language->get('text_register');
		$data['text_guest'] 					= $this->language->get('text_guest');
		$data['text_login'] 					= $this->language->get('text_login');
		$data['text_shopping_cart'] 			= $this->language->get('text_shopping_cart');
		$data['text_shopping_cart_status'] 		= $this->language->get('text_shopping_cart_status');
		$data['text_show_weight'] 				= $this->language->get('text_show_weight');
		$data['text_quantity_update_permission'] = $this->language->get('text_quantity_update_permission');
		$data['text_show_removecart'] 			= $this->language->get('text_show_removecart');
		$data['text_product_image_size'] 		= $this->language->get('text_product_image_size');
		$data['text_delivery_methods'] 			= $this->language->get('text_delivery_methods');
		$data['text_delivery_methods_status'] 	= $this->language->get('text_delivery_methods_status');
		$data['text_payment_methods_status'] 	= $this->language->get('text_payment_methods_status');
		$data['text_payment_methods'] 			= $this->language->get('text_payment_methods');
		$data['text_confirm_order'] 			= $this->language->get('text_confirm_order');
		$data['text_add_comments'] 				= $this->language->get('text_add_comments');
		$data['text_require_comment'] 			= $this->language->get('text_require_comment');
		$data['text_show_newsletter'] 			= $this->language->get('text_show_newsletter');
		$data['text_show_privacy'] 				= $this->language->get('text_show_privacy');
		$data['text_show_term'] 				= $this->language->get('text_show_term');
		$data['text_checkout_order_button'] 	= $this->language->get('text_checkout_order_buttons');
		$data['text_coupon_voucher'] 			= $this->language->get('text_coupon_voucher');
		$data['text_login_account'] 			= $this->language->get('text_login_account');
		$data['text_coupon'] 					= $this->language->get('text_coupon');
		$data['text_reward'] 					= $this->language->get('text_reward');
		$data['text_voucher'] 					= $this->language->get('text_voucher');
		$data['text_status'] 					= $this->language->get('text_status');
		$data['text_layout_three'] 				= $this->language->get('text_layout_three');
		$data['text_shipping_methods'] 			= $this->language->get('text_shipping_methods');
		$data['text_show_name'] 				= $this->language->get('text_show_name');
		$data['text_show_surname'] 				= $this->language->get('text_show_surname');
		$data['text_show_phone'] 				= $this->language->get('text_show_phone');
		$data['text_show_fax'] 				= $this->language->get('text_show_fax');
		$data['text_show_company'] 				= $this->language->get('text_show_company');
		$data['text_show_adress'] 				= $this->language->get('text_show_adress');
		$data['text_show_secondadress'] 				= $this->language->get('text_show_secondadress');
		$data['text_show_mail'] 				= $this->language->get('text_show_mail');
		$data['text_show_postcode'] 				= $this->language->get('text_show_postcode');
		$data['text_show_city'] 				= $this->language->get('text_show_city');
		$data['text_show_country'] 				= $this->language->get('text_show_country');
		$data['text_show_state'] 				= $this->language->get('text_show_state');
		$data['text_field'] 				= $this->language->get('text_field');
		$data['button_save'] = $this->language->get('button_save');
		$data['button_cancel'] = $this->language->get('button_cancel');
		$data['entry_name_title'] = $this->language->get('entry_name_title');
		$data['entry_status_title'] = $this->language->get('entry_status_title');
		
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['error_name'])) {
			$data['error_name'] = $this->error['error_name'];
		} else {
			$data['error_name'] = '';
		}

		if (isset($this->error['error_product_image_width'])) {
			$data['error_product_image_width'] = $this->error['error_product_image_width'];
		} else {
			$data['error_product_image_width'] = '';
		}

		if (isset($this->error['error_product_image_height'])) {
			$data['error_product_image_height'] = $this->error['error_product_image_height'];
		} else {
			$data['error_product_image_height'] = '';
		}
		
		if (!isset($this->request->get['module_id'])) {
			$data['action'] = $this->url->link('extension/module/onepagecheckout', 'user_token=' . $this->session->data['user_token'], 'SSL');
		} else {
			$data['action'] = $this->url->link('extension/module/onepagecheckout', 'user_token=' . $this->session->data['user_token'] . '&module_id=' . $this->request->get['module_id'], 'SSL');
		}
		$data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true);
		$setting_onepagecheckout					= $this->model_setting_setting->getSetting('onepagecheckout');
		$setting_onepagecheckout_general			= isset($setting_onepagecheckout['onepagecheckout_general']) ? $setting_onepagecheckout['onepagecheckout_general'] : array();
		$setting_onepagecheckout_layout_setting	= isset($setting_onepagecheckout['onepagecheckout_layout_setting']) ? $setting_onepagecheckout['onepagecheckout_layout_setting'] : array();
		$params 				= isset($this->request->post['onepagecheckout']) ? $this->request->post['onepagecheckout'] : array();
		$params_general 		= isset($this->request->post['onepagecheckout']['onepagecheckout_general']) ? $this->request->post['onepagecheckout']['onepagecheckout_general'] : array();
		$params_layout_setting 	= isset($this->request->post['onepagecheckout']['onepagecheckout_layout_setting']) ? $this->request->post['onepagecheckout']['onepagecheckout_layout_setting'] : array();
		if (isset($params_general['onepagecheckout_name'])) {
			$data['onepagecheckout_name'] = $params_general['onepagecheckout_name'];
		} elseif (!empty($setting_onepagecheckout_general)) {
			$data['onepagecheckout_name'] = isset($setting_onepagecheckout_general['onepagecheckout_name']) ? $setting_onepagecheckout_general['onepagecheckout_name'] : '';
		} else {
			$data['onepagecheckout_name'] = '';
		}
		if (isset($params_general['onepagecheckout_layout'])) {
			$data['onepagecheckout_layout'] = $params_general['onepagecheckout_layout'];
		} elseif (!empty($setting_onepagecheckout_general)) {
			$data['onepagecheckout_layout'] = isset($setting_onepagecheckout_general['onepagecheckout_layout']) ? $setting_onepagecheckout_general['onepagecheckout_layout'] : '';
		} else {
			$data['onepagecheckout_layout'] = '';
		}
		if (isset($params_general['onepagecheckout_enabled'])) {
			$data['onepagecheckout_enabled'] = $params_general['onepagecheckout_enabled'];
		} elseif (!empty($setting_onepagecheckout_general)) {
			$data['onepagecheckout_enabled'] = isset($setting_onepagecheckout_general['onepagecheckout_enabled']) ? $setting_onepagecheckout_general['onepagecheckout_enabled'] : '';
		} else {
			$data['onepagecheckout_enabled'] = '';
		}
		if (isset($params_general['onepagecheckout_country_id'])) {
			$data['onepagecheckout_country_id'] = $params_general['onepagecheckout_country_id'];
		} elseif (!empty($setting_onepagecheckout_general)) {
			$data['onepagecheckout_country_id'] = isset($setting_onepagecheckout_general['onepagecheckout_country_id']) ? $setting_onepagecheckout_general['onepagecheckout_country_id'] : '';
		} else {
			$data['onepagecheckout_country_id'] = '';
		}
		if (isset($params_general['onepagecheckout_zone_id'])) {
			$data['onepagecheckout_zone_id'] = $params_general['onepagecheckout_zone_id'];
		} elseif (!empty($setting_onepagecheckout_general)) {
			$data['onepagecheckout_zone_id'] = isset($setting_onepagecheckout_general['onepagecheckout_zone_id']) ? $setting_onepagecheckout_general['onepagecheckout_zone_id'] : '';
		} else {
			$data['onepagecheckout_zone_id'] = '';
		}
		if (isset($params_layout_setting['onepagecheckout_register_checkout'])) {
			$data['onepagecheckout_register_checkout'] = $params_layout_setting['onepagecheckout_register_checkout'];
		} elseif (!empty($setting_onepagecheckout_layout_setting)) {
			$data['onepagecheckout_register_checkout'] = isset($setting_onepagecheckout_layout_setting['onepagecheckout_register_checkout']) ? $setting_onepagecheckout_layout_setting['onepagecheckout_register_checkout'] : '';
		} else {
			$data['onepagecheckout_register_checkout'] = '';
		}
		if (isset($params_layout_setting['onepagecheckout_guest_checkout'])) {
			$data['onepagecheckout_guest_checkout'] = $params_layout_setting['onepagecheckout_guest_checkout'];
		} elseif (!empty($setting_onepagecheckout_layout_setting)) {
			$data['onepagecheckout_guest_checkout'] = isset($setting_onepagecheckout_layout_setting['onepagecheckout_guest_checkout']) ? $setting_onepagecheckout_layout_setting['onepagecheckout_guest_checkout'] : '';
		} else {
			$data['onepagecheckout_guest_checkout'] = '';
		}
		if (isset($params_layout_setting['onepagecheckout_enable_login'])) {
			$data['onepagecheckout_enable_login'] = $params_layout_setting['onepagecheckout_enable_login'];
		} elseif (!empty($setting_onepagecheckout_layout_setting)) {
			$data['onepagecheckout_enable_login'] = isset($setting_onepagecheckout_layout_setting['onepagecheckout_enable_login']) ? $setting_onepagecheckout_layout_setting['onepagecheckout_enable_login'] : '';
		} else {
			$data['onepagecheckout_enable_login'] = '';
		}
		if (isset($params_layout_setting['onepagecheckout_account_open'])) {
			$data['onepagecheckout_account_open'] = $params_layout_setting['onepagecheckout_account_open'];
		} elseif (!empty($setting_onepagecheckout_layout_setting)) {
			$data['onepagecheckout_account_open'] = isset($setting_onepagecheckout_layout_setting['onepagecheckout_account_open']) ? $setting_onepagecheckout_layout_setting['onepagecheckout_account_open'] : '';
		} else {
			$data['onepagecheckout_account_open'] = '';
		}
		if (isset($params_layout_setting['shopping_cart_status'])) {
			$data['shopping_cart_status'] = $params_layout_setting['shopping_cart_status'];
		} elseif (!empty($setting_onepagecheckout_layout_setting)) {
			$data['shopping_cart_status'] = isset($setting_onepagecheckout_layout_setting['shopping_cart_status']) ? $setting_onepagecheckout_layout_setting['shopping_cart_status'] : '';
		} else {
			$data['shopping_cart_status'] = '';
		}
		if (isset($params_layout_setting['show_product_weight'])) {
			$data['show_product_weight'] = $params_layout_setting['show_product_weight'];
		} elseif (!empty($setting_onepagecheckout_layout_setting)) {
			$data['show_product_weight'] = isset($setting_onepagecheckout_layout_setting['show_product_weight']) ? $setting_onepagecheckout_layout_setting['show_product_weight'] : '';
		} else {
			$data['show_product_weight'] = '';
		}
		if (isset($params_layout_setting['show_product_qnty_update'])) {
			$data['show_product_qnty_update'] = $params_layout_setting['show_product_qnty_update'];
		} elseif (!empty($setting_onepagecheckout_layout_setting)) {
			$data['show_product_qnty_update'] = isset($setting_onepagecheckout_layout_setting['show_product_qnty_update']) ? $setting_onepagecheckout_layout_setting['show_product_qnty_update'] : '';
		} else {
			$data['show_product_qnty_update'] = '';
		}
		if (isset($params_layout_setting['show_product_removecart'])) {
			$data['show_product_removecart'] = $params_layout_setting['show_product_removecart'];
		} elseif (!empty($setting_onepagecheckout_layout_setting)) {
			$data['show_product_removecart'] = isset($setting_onepagecheckout_layout_setting['show_product_removecart']) ? $setting_onepagecheckout_layout_setting['show_product_removecart'] : '';
		} else {
			$data['show_product_removecart'] = '';
		}
		if (isset($params_layout_setting['show_product_image_width'])) {
			$data['show_product_image_width'] = $params_layout_setting['show_product_image_width'];
		} elseif (!empty($setting_onepagecheckout_layout_setting)) {
			$data['show_product_image_width'] = isset($setting_onepagecheckout_layout_setting['show_product_image_width']) ? $setting_onepagecheckout_layout_setting['show_product_image_width'] : '';
		} else {
			$data['show_product_image_width'] = '';
		}
		if (isset($params_layout_setting['show_product_image_height'])) {
			$data['show_product_image_height'] = $params_layout_setting['show_product_image_height'];
		} elseif (!empty($setting_onepagecheckout_layout_setting)) {
			$data['show_product_image_height'] = isset($setting_onepagecheckout_layout_setting['show_product_image_height']) ? $setting_onepagecheckout_layout_setting['show_product_image_height'] : '';
		} else {
			$data['show_product_image_height'] = '';
		}
		if (isset($params_layout_setting['delivery_method_status'])) {
			$data['delivery_method_status'] = $params_layout_setting['delivery_method_status'];
		} elseif (!empty($setting_onepagecheckout_layout_setting)) {
			$data['delivery_method_status'] = isset($setting_onepagecheckout_layout_setting['delivery_method_status']) ? $setting_onepagecheckout_layout_setting['delivery_method_status'] : '';
		} else {
			$data['delivery_method_status'] = '';
		}
		if (isset($params_layout_setting['comment_status'])) {
			$data['comment_status'] = $params_layout_setting['comment_status'];
		} elseif (!empty($setting_onepagecheckout_layout_setting)) {
			$data['comment_status'] = isset($setting_onepagecheckout_layout_setting['comment_status']) ? $setting_onepagecheckout_layout_setting['comment_status'] : '';
		} else {
			$data['comment_status'] = '';
		}
		if (isset($params_layout_setting['require_comment_status'])) {
			$data['require_comment_status'] = $params_layout_setting['require_comment_status'];
		} elseif (!empty($setting_onepagecheckout_layout_setting)) {
			$data['require_comment_status'] = isset($setting_onepagecheckout_layout_setting['require_comment_status']) ? $setting_onepagecheckout_layout_setting['require_comment_status'] : '';
		} else {
			$data['require_comment_status'] = '';
		}
		if (isset($params_layout_setting['show_newsletter'])) {
			$data['show_newsletter'] = $params_layout_setting['show_newsletter'];
		} elseif (!empty($setting_onepagecheckout_layout_setting)) {
			$data['show_newsletter'] = isset($setting_onepagecheckout_layout_setting['show_newsletter']) ? $setting_onepagecheckout_layout_setting['show_newsletter'] : '';
		} else {
			$data['show_newsletter'] = '';
		}
		if (isset($params_layout_setting['show_privacy'])) {
			$data['show_privacy'] = $params_layout_setting['show_privacy'];
		} elseif (!empty($setting_onepagecheckout_layout_setting)) {
			$data['show_privacy'] = isset($setting_onepagecheckout_layout_setting['show_privacy']) ? $setting_onepagecheckout_layout_setting['show_privacy'] : '';
		} else {
			$data['show_privacy'] = '';
		}
		if (isset($params_layout_setting['show_term'])) {
			$data['show_term'] = $params_layout_setting['show_term'];
		} elseif (!empty($setting_onepagecheckout_layout_setting)) {
			$data['show_term'] = isset($setting_onepagecheckout_layout_setting['show_term']) ? $setting_onepagecheckout_layout_setting['show_term'] : '';
		} else {
			$data['show_term'] = '';
		}
		if (isset($params_layout_setting['confirm_button_status'])) {
			$data['confirm_button_status'] = $params_layout_setting['confirm_button_status'];
		} elseif (!empty($setting_onepagecheckout_layout_setting)) {
			$data['confirm_button_status'] = isset($setting_onepagecheckout_layout_setting['confirm_button_status']) ? $setting_onepagecheckout_layout_setting['confirm_button_status'] : '';
		} else {
			$data['confirm_button_status'] = '';
		}
		if (isset($params_layout_setting['coupon_login_status'])) {
			$data['coupon_login_status'] = $params_layout_setting['coupon_login_status'];
		} elseif (!empty($setting_onepagecheckout_layout_setting)) {
			$data['coupon_login_status'] = isset($setting_onepagecheckout_layout_setting['coupon_login_status']) ? $setting_onepagecheckout_layout_setting['coupon_login_status'] : '';
		} else {
			$data['coupon_login_status'] = '';
		}
		if (isset($params_layout_setting['coupon_register_status'])) {
			$data['coupon_register_status'] = $params_layout_setting['coupon_register_status'];
		} elseif (!empty($setting_onepagecheckout_layout_setting)) {
			$data['coupon_register_status'] = isset($setting_onepagecheckout_layout_setting['coupon_register_status']) ? $setting_onepagecheckout_layout_setting['coupon_register_status'] : '';
		} else {
			$data['coupon_register_status'] = '';
		}
		if (isset($params_layout_setting['coupon_guest_status'])) {
			$data['coupon_guest_status'] = $params_layout_setting['coupon_guest_status'];
		} elseif (!empty($setting_onepagecheckout_layout_setting)) {
			$data['coupon_guest_status'] = isset($setting_onepagecheckout_layout_setting['coupon_guest_status']) ? $setting_onepagecheckout_layout_setting['coupon_guest_status'] : '';
		} else {
			$data['coupon_guest_status'] = '';
		}
		if (isset($params_layout_setting['reward_login_status'])) {
			$data['reward_login_status'] = $params_layout_setting['reward_login_status'];
		} elseif (!empty($setting_onepagecheckout_layout_setting)) {
			$data['reward_login_status'] = isset($setting_onepagecheckout_layout_setting['reward_login_status']) ? $setting_onepagecheckout_layout_setting['reward_login_status'] : '';
		} else {
			$data['reward_login_status'] = '';
		}
		if (isset($params_layout_setting['reward_register_status'])) {
			$data['reward_register_status'] = $params_layout_setting['reward_register_status'];
		} elseif (!empty($setting_onepagecheckout_layout_setting)) {
			$data['reward_register_status'] = isset($setting_onepagecheckout_layout_setting['reward_register_status']) ? $setting_onepagecheckout_layout_setting['reward_register_status'] : '';
		} else {
			$data['reward_register_status'] = '';
		}
		if (isset($params_layout_setting['reward_guest_status'])) {
			$data['reward_guest_status'] = $params_layout_setting['reward_guest_status'];
		} elseif (!empty($setting_onepagecheckout_layout_setting)) {
			$data['reward_guest_status'] = isset($setting_onepagecheckout_layout_setting['reward_guest_status']) ? $setting_onepagecheckout_layout_setting['reward_guest_status'] : '';
		} else {
			$data['reward_guest_status'] = '';
		}
		if (isset($params_layout_setting['voucher_login_status'])) {
			$data['voucher_login_status'] = $params_layout_setting['voucher_login_status'];
		} elseif (!empty($setting_onepagecheckout_layout_setting)) {
			$data['voucher_login_status'] = isset($setting_onepagecheckout_layout_setting['voucher_login_status']) ? $setting_onepagecheckout_layout_setting['voucher_login_status'] : '';
		} else {
			$data['voucher_login_status'] = '';
		}
		if (isset($params_layout_setting['voucher_register_status'])) {
			$data['voucher_register_status'] = $params_layout_setting['voucher_register_status'];
		} elseif (!empty($setting_onepagecheckout_layout_setting)) {
			$data['voucher_register_status'] = isset($setting_onepagecheckout_layout_setting['voucher_register_status']) ? $setting_onepagecheckout_layout_setting['voucher_register_status'] : '';
		} else {
			$data['voucher_register_status'] = '';
		}
		if (isset($params_layout_setting['voucher_guest_status'])) {
			$data['voucher_guest_status'] = $params_layout_setting['voucher_guest_status'];
		} elseif (!empty($setting_onepagecheckout_layout_setting)) {
			$data['voucher_guest_status'] = isset($setting_onepagecheckout_layout_setting['voucher_guest_status']) ? $setting_onepagecheckout_layout_setting['voucher_guest_status'] : '';
		} else {
			$data['voucher_guest_status'] = '';
		}
		if (isset($params_layout_setting['payment_method_status'])) {
			$data['payment_method_status'] = $params_layout_setting['payment_method_status'];
		} elseif (!empty($setting_onepagecheckout_layout_setting)) {
			$data['payment_method_status'] = isset($setting_onepagecheckout_layout_setting['payment_method_status']) ? $setting_onepagecheckout_layout_setting['payment_method_status'] : '';
		} else {
			$data['payment_method_status'] = '';
		}
		if (isset($params_layout_setting['onepagecheckout_default_payment'])) {
			$data['onepagecheckout_default_payment'] = $params_layout_setting['onepagecheckout_default_payment'];
		} elseif (!empty($setting_onepagecheckout_layout_setting)) {
			$data['onepagecheckout_default_payment'] = isset($setting_onepagecheckout_layout_setting['onepagecheckout_default_payment']) ? $setting_onepagecheckout_layout_setting['onepagecheckout_default_payment'] : '';
		} else {
			$data['onepagecheckout_default_payment'] = '';
		}
		if (isset($params_layout_setting['onepagecheckout_default_shipping'])) {
			$data['onepagecheckout_default_shipping'] = $params_layout_setting['onepagecheckout_default_shipping'];
		} elseif (!empty($setting_onepagecheckout_layout_setting)) {
			$data['onepagecheckout_default_shipping'] = isset($setting_onepagecheckout_layout_setting['onepagecheckout_default_shipping']) ? $setting_onepagecheckout_layout_setting['onepagecheckout_default_shipping'] : '';
		} else {
			$data['onepagecheckout_default_shipping'] = '';
		}
		if (isset($params_layout_setting['show_fax'])) {
			$data['show_fax'] = $params_layout_setting['show_fax'];
		} elseif (!empty($setting_onepagecheckout_layout_setting)) {
			$data['show_fax'] = isset($setting_onepagecheckout_layout_setting['show_fax']) ? $setting_onepagecheckout_layout_setting['show_fax'] : '';
		} else {
			$data['show_fax'] = '';
		}
			if (isset($params_layout_setting['show_name'])) {
			$data['show_name'] = $params_layout_setting['show_name'];
		} elseif (!empty($setting_onepagecheckout_layout_setting)) {
			$data['show_name'] = isset($setting_onepagecheckout_layout_setting['show_name']) ? $setting_onepagecheckout_layout_setting['show_name'] : '';
		} else {
			$data['show_name'] = '';
		}
			if (isset($params_layout_setting['show_surname'])) {
			$data['show_surname'] = $params_layout_setting['show_surname'];
		} elseif (!empty($setting_onepagecheckout_layout_setting)) {
			$data['show_surname'] = isset($setting_onepagecheckout_layout_setting['show_surname']) ? $setting_onepagecheckout_layout_setting['show_surname'] : '';
		} else {
			$data['show_surname'] = '';
		}
			if (isset($params_layout_setting['show_phone'])) {
			$data['show_phone'] = $params_layout_setting['show_phone'];
		} elseif (!empty($setting_onepagecheckout_layout_setting)) {
			$data['show_phone'] = isset($setting_onepagecheckout_layout_setting['show_phone']) ? $setting_onepagecheckout_layout_setting['show_phone'] : '';
		} else {
			$data['show_phone'] = '';
		}
			if (isset($params_layout_setting['show_company'])) {
			$data['show_company'] = $params_layout_setting['show_company'];
		} elseif (!empty($setting_onepagecheckout_layout_setting)) {
			$data['show_company'] = isset($setting_onepagecheckout_layout_setting['show_company']) ? $setting_onepagecheckout_layout_setting['show_company'] : '';
		} else {
			$data['show_company'] = '';
		}
			if (isset($params_layout_setting['show_adress'])) {
			$data['show_adress'] = $params_layout_setting['show_adress'];
		} elseif (!empty($setting_onepagecheckout_layout_setting)) {
			$data['show_adress'] = isset($setting_onepagecheckout_layout_setting['show_adress']) ? $setting_onepagecheckout_layout_setting['show_adress'] : '';
		} else {
			$data['show_adress'] = '';
		}
			if (isset($params_layout_setting['show_secondadress'])) {
			$data['show_secondadress'] = $params_layout_setting['show_secondadress'];
		} elseif (!empty($setting_onepagecheckout_layout_setting)) {
			$data['show_secondadress'] = isset($setting_onepagecheckout_layout_setting['show_secondadress']) ? $setting_onepagecheckout_layout_setting['show_secondadress'] : '';
		} else {
			$data['show_secondadress'] = '';
		}
		if (isset($params_layout_setting['show_mail'])) {
			$data['show_mail'] = $params_layout_setting['show_mail'];
		} elseif (!empty($setting_onepagecheckout_layout_setting)) {
			$data['show_mail'] = isset($setting_onepagecheckout_layout_setting['show_mail']) ? $setting_onepagecheckout_layout_setting['show_mail'] : '';
		} else {
			$data['show_mail'] = '';
		}
			if (isset($params_layout_setting['show_postcode'])) {
			$data['show_postcode'] = $params_layout_setting['show_postcode'];
		} elseif (!empty($setting_onepagecheckout_layout_setting)) {
			$data['show_postcode'] = isset($setting_onepagecheckout_layout_setting['show_postcode']) ? $setting_onepagecheckout_layout_setting['show_postcode'] : '';
		} else {
			$data['show_postcode'] = '';
		}
			if (isset($params_layout_setting['show_city'])) {
			$data['show_city'] = $params_layout_setting['show_city'];
		} elseif (!empty($setting_onepagecheckout_layout_setting)) {
			$data['show_city'] = isset($setting_onepagecheckout_layout_setting['show_city']) ? $setting_onepagecheckout_layout_setting['show_city'] : '';
		} else {
			$data['show_city'] = '';
		}
		
		if (isset($params_layout_setting['show_country'])) {
			$data['show_country'] = $params_layout_setting['show_country'];
		} elseif (!empty($setting_onepagecheckout_layout_setting)) {
			$data['show_country'] = isset($setting_onepagecheckout_layout_setting['show_country']) ? $setting_onepagecheckout_layout_setting['show_country'] : '';
		} else {
			$data['show_country'] = '';
		}
		
			if (isset($params_layout_setting['show_state'])) {
			$data['show_state'] = $params_layout_setting['show_state'];
		} elseif (!empty($setting_onepagecheckout_layout_setting)) {
			$data['show_state'] = isset($setting_onepagecheckout_layout_setting['show_state']) ? $setting_onepagecheckout_layout_setting['show_state'] : '';
		} else {
			$data['show_state'] = '';
		}
		$data['payment_methods']	= $this->model_extension_module_onepagecheckout->getPaymentMethods();
		$data['shipping_methods']	= $this->model_extension_module_onepagecheckout->getShippingMethods();
		$data['setting_onepagecheckout_layout_setting']	= $setting_onepagecheckout_layout_setting;
        $data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		$this->response->setOutput($this->load->view('extension/module/onepagecheckout', $data));
	}
	protected function validate() {
		if (!$this->user->hasPermission('modify', 'extension/module/onepagecheckout')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		$params					= $this->request->post['onepagecheckout'];
		$params_general 		= $params['onepagecheckout_general'];
		$params_layout_setting 	= $params['onepagecheckout_layout_setting'];
		
		if ((utf8_strlen($params_general['onepagecheckout_name']) < 3) || (utf8_strlen($params_general['onepagecheckout_name']) > 64)) {
			$this->error['error_name'] = $this->language->get('error_name');
			$this->error['warning'] = $this->language->get('error_warning');
		}

		if (!empty($params_layout_setting['show_product_image_width'])) {
			if (!is_numeric($params_layout_setting['show_product_image_width'])) {
				$this->error['error_product_image_width'] = $this->language->get('error_product_image_width');
				$this->error['warning'] = $this->language->get('error_warning');
			}
		}

		if (!empty($params_layout_setting['show_product_image_height'])) {
			if (!is_numeric($params_layout_setting['show_product_image_height'])) {
				$this->error['error_product_image_height'] = $this->language->get('error_product_image_height');
				$this->error['warning'] = $this->language->get('error_warning');
			}
		}
		
		return !$this->error;
	}

	function install() {
		$this->load->model('setting/setting');
		$this->load->model('setting/module');

		$data	= array(
			'onepagecheckout_general'	=> array(
				'onepagecheckout_enabled'	=> 1,
				'onepagecheckout_name'		=> 'Onepage Checkout',
				'onepagecheckout_layout'		=> 1,
				'onepagecheckout_country_id'	=> 220,
				'onepagecheckout_zone_id'	=> 3490
			),	
			'onepagecheckout_layout_setting'	=> array(
				'onepagecheckout_register_checkout'	=> 1,
				'onepagecheckout_guest_checkout'	=> 1,
				'onepagecheckout_enable_login'	=> 1,
				'onepagecheckout_account_open'	=> 'register',
				'shopping_cart_status'	=> 1,
				'show_product_weight'	=> 1,
				'show_product_qnty_update'	=> 1,
				'show_product_removecart'	=> 1,
				'show_product_image_width'	=> 80,
				'show_product_image_height'	=> 80,
				'coupon_login_status'	=> 1,
				'coupon_register_status'	=> 1,
				'coupon_guest_status'	=> 1,
				'reward_login_status'	=> 1,
				'reward_register_status'	=> 1,
				'reward_guest_status'	=> 1,
				'voucher_login_status'	=> 1,
				'voucher_register_status'	=> 1,
				'voucher_guest_status'	=> 1,
				'delivery_method_status'	=> 1,
				'onepagecheckout_layout_setting'	=> 'free',
				'flat_status'	=> 1,
				'free_status'	=> 1,
				'free_status'	=> 1,
				'payment_method_status'	=> 1,
				'onepagecheckout_default_payment'	=> 'bank_transfer',
				'bank_transfer_status'	=> 1,
				'cod_status'	=> 1,
				'comment_status'	=> 1,
				'require_comment_status'	=> 1,
				'show_newsletter'	=> 1,
				'show_privacy'	=> 1,
				'show_term'	=> 1,
				'show_name'	=> 1,
				'show_surname'	=> 1,
				'show_phone'	=> 1,
				'show_fax'	=> 1,
				'show_company'	=> 1,
				'show_postcode'	=> 1,
				'show_mail'	=> 1,
				'show_city'	=> 1,
				'show_country'	=> 1,
				'show_state'	=> 1,
			)
		);

		$data_module = array('name'=>'Onepage Checkout', 'status'=>1);
		$this->model_setting_setting->editSetting('onepagecheckout', $data);
		$this->model_setting_module->addModule('onepagecheckout', $data_module);
	}

	function uninstall() {
		$this->load->model('setting/setting');
		$this->load->model('setting/module');
		$this->model_setting_setting->deleteSetting('onepagecheckout');
		$this->model_setting_module->deleteModulesByCode('onepagecheckout');
	}
}