<?php
	global $registry;
	$registry = new Registry();
  	$registry->set('currency', new Currency($registry));
    require_once(DIR_SYSTEM . 'library/onepagecheckout/classes/utils.php');
    global $utils;
    $utils = new Utils();
    $this->registry->set('utils', $utils);